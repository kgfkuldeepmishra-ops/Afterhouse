# AfterHours backend starter

This is a **development scaffold**, not a production-ready service. It lays out the backend boundaries for:
- accepted-chat-only phone number visibility;
- encrypted-at-rest phone numbers and message bodies (AES-256-GCM);
- user-submitted reports;
- moderator access scoped to a specific report;
- an audit event whenever a moderator opens a report.

## Important product/privacy decisions

1. Phone numbers are never public. `GET /conversations/:id/contact` returns the other participant's number only when the caller belongs to that conversation and its status is `ACCEPTED`.
2. This is **not end-to-end encryption**. The server holds the encryption key and can decrypt content for a reported-message review. Tell users this plainly before signup.
3. This starter only decrypts the message explicitly attached to a report. It does not provide blanket admin browsing of private chats.
4. The sample schema supports one-to-one conversations. Group chat requires a different membership model and a separate decision about phone-number visibility.
5. Uploaded files are not implemented. Add private object storage, malware scanning, content-type/size checks, short-lived signed URLs, and report-scoped moderator access before accepting uploads.
6. Production authentication is not implemented. Integrate an SMS OTP provider with rate limits, resend cooldowns, SIM-swap/abuse controls, and account recovery. Never store OTPs in plaintext. The `/dev/token` route is disabled unless `ALLOW_DEV_AUTH=true`; do not enable it in production.
7. Do not deploy until a security review, privacy notice, retention/deletion policy, incident-response plan, age-assurance plan, and India-specific legal review are complete.

## Run locally

Requirements: Node.js 20+, Docker.

```bash
cp .env.example .env
```

Generate secrets. Example commands (run locally; do not reuse these sample values):
```bash
openssl rand -base64 32
openssl rand -hex 32
```
Set `PHONE_ENCRYPTION_KEY` to the base64 output (must decode to 32 bytes), and set `JWT_SECRET` and `PHONE_LOOKUP_HMAC_KEY` to independent random secrets of at least 32 characters.

Start PostgreSQL and install dependencies:
```bash
docker compose up -d db
npm install
npx prisma generate
npx prisma migrate dev --name initial
npm run dev
```

In a second terminal, serve the frontend:
```bash
python3 -m http.server 5173 --directory web
```

Open `http://localhost:5173`. The API listens on `http://localhost:4000`. `GET /health` is a simple health check.

## Website registration/sign-in demo

A minimal frontend is included at `web/index.html`. Open it in a browser while the API is running, set the API address (default `http://localhost:4000`), and use the sign-up/sign-in tabs.

For local testing only:
- Set `ALLOW_DEV_AUTH=true` in `.env`.
- Start the API and database, then open `web/index.html`.
- Sign up with a display name and a placeholder phone number in international format (for example `+919876543210`).
- Sign in again with the same number.

**This is not real phone verification.** The development endpoints do not send OTPs and must remain disabled in production. Do not use real personal phone numbers in this demo. Replace `/dev/register` and `/dev/login` with an SMS OTP provider flow before launch. Store tokens in secure, HttpOnly cookies in production rather than browser storage.

## Initial endpoints

- `POST /dev/register` — development-only signup; no phone ownership verification\n- `POST /dev/login` — development-only login; no OTP\n- `GET /health`
- `GET /me` — authenticated user profile
- `GET /conversations/:id/contact` — returns the other participant's phone number only in an accepted conversation
- `POST /conversations/:id/messages` — adds an encrypted message to an accepted conversation
- `POST /conversations/:id/reports` — files a safety report, optionally tied to a message
- `GET /moderation/reports/:id` — moderator-only, report-scoped review; writes an audit log

The database needs users, conversations and moderators to be provisioned through a trusted onboarding/admin process; this scaffold intentionally does not create public signup or moderator provisioning routes.

## Before production

- Replace the dev token helper with verified OTP login and short-lived access/refresh token rotation.
- Add conversation creation/accept/decline/block endpoints and enforce canonical participant ordering.
- Add per-user rate limits, abuse detection, CSRF protection if cookie auth is used, strict CORS origins, request validation, structured redacted logs, backups and key rotation.
- Add a proper moderator console with least-privilege roles, reason-for-access capture, audit-log review, dual control for exceptional access, and alerts for unusual access.
- Add file uploads only after private bucket permissions, virus/malware scanning, metadata stripping where appropriate, file size/type allowlists, signed URL expiry and report-scoped review are implemented.
- Define retention and deletion periods for messages, reports, logs and backups; document lawful disclosure and user appeal processes.
- Obtain qualified Indian legal advice before enabling adult or explicit material. This code does not determine legal compliance.
