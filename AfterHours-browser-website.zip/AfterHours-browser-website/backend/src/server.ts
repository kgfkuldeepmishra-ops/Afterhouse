import "dotenv/config";
import express, { Request, Response, NextFunction } from "express";
import helmet from "helmet";
import cors from "cors";
import jwt from "jsonwebtoken";
import { PrismaClient, ConversationStatus, AuditAction } from "@prisma/client";
import { z } from "zod";
import { createCipheriv, createDecipheriv, createHmac, randomBytes } from "node:crypto";

const app = express();
const prisma = new PrismaClient();
app.use(helmet());
app.use(cors({ origin: process.env.APP_ORIGIN?.split(",") ?? false }));
app.use(express.json({ limit: "64kb" }));

const jwtSecret = process.env.JWT_SECRET;
const encKey = process.env.PHONE_ENCRYPTION_KEY;
const lookupKey = process.env.PHONE_LOOKUP_HMAC_KEY;
if (!jwtSecret || jwtSecret.length < 32 || !encKey || !lookupKey || lookupKey.length < 32) {
  throw new Error("Set JWT_SECRET, PHONE_ENCRYPTION_KEY and PHONE_LOOKUP_HMAC_KEY before starting.");
}
const key = Buffer.from(encKey, "base64");
if (key.length !== 32) throw new Error("PHONE_ENCRYPTION_KEY must decode to exactly 32 bytes.");

type TokenPayload = { sub: string; role?: string };
type AuthedRequest = Request & { auth?: TokenPayload };

function encrypt(value: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ciphertext = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return { ciphertext: ciphertext.toString("base64"), iv: iv.toString("base64"), tag: cipher.getAuthTag().toString("base64") };
}
function decrypt(ciphertext: string, iv: string, tag: string) {
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(iv, "base64"));
  decipher.setAuthTag(Buffer.from(tag, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(ciphertext, "base64")), decipher.final()]).toString("utf8");
}
function phoneHash(phone: string) {
  return createHmac("sha256", lookupKey!).update(phone).digest("hex");
}
function auth(req: AuthedRequest, res: Response, next: NextFunction) {
  const raw = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!raw) return res.status(401).json({ error: "Authentication required" });
  try { req.auth = jwt.verify(raw, jwtSecret!) as TokenPayload; next(); }
  catch { return res.status(401).json({ error: "Invalid or expired token" }); }
}
function moderatorAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  auth(req, res, async () => {
    const moderator = await prisma.moderator.findUnique({ where: { id: req.auth!.sub } });
    if (!moderator?.active) return res.status(403).json({ error: "Moderator access required" });
    (req as any).moderator = moderator;
    next();
  });
}
function isParticipant(conversation: any, userId: string) {
  return conversation && (conversation.participantA === userId || conversation.participantB === userId);
}
function otherParticipant(conversation: any, userId: string) {
  return conversation.participantA === userId ? conversation.participantB : conversation.participantA;
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "afterhours-api" }));


// DEVELOPMENT-ONLY signup/login. This does NOT verify phone ownership.
// Replace with a real SMS OTP provider before any public deployment.
app.post("/dev/register", async (req, res) => {
  if (process.env.ALLOW_DEV_AUTH !== "true") return res.status(404).end();
  const parsed = z.object({
    displayName: z.string().trim().min(2).max(40),
    phone: z.string().regex(/^\+[1-9]\d{7,14}$/)
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Enter a name and phone number in international format, e.g. +919876543210" });
  const lookup = phoneHash(parsed.data.phone);
  const existing = await prisma.user.findUnique({ where: { phoneLookupHash: lookup } });
  if (existing) return res.status(409).json({ error: "An account with this phone number already exists. Try signing in." });
  const encrypted = encrypt(parsed.data.phone);
  const user = await prisma.user.create({ data: {
    displayName: parsed.data.displayName,
    phoneCiphertext: encrypted.ciphertext,
    phoneIv: encrypted.iv,
    phoneAuthTag: encrypted.tag,
    phoneLookupHash: lookup
  }, select: { id: true, displayName: true } });
  const token = jwt.sign({ sub: user.id }, jwtSecret!, { expiresIn: "30m" });
  return res.status(201).json({ user, token, demoOnly: true });
});

app.post("/dev/login", async (req, res) => {
  if (process.env.ALLOW_DEV_AUTH !== "true") return res.status(404).end();
  const parsed = z.object({ phone: z.string().regex(/^\+[1-9]\d{7,14}$/) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Enter a phone number in international format." });
  const user = await prisma.user.findUnique({
    where: { phoneLookupHash: phoneHash(parsed.data.phone) },
    select: { id: true, displayName: true }
  });
  if (!user) return res.status(401).json({ error: "No account found. Create an account first." });
  const token = jwt.sign({ sub: user.id }, jwtSecret!, { expiresIn: "30m" });
  return res.json({ user, token, demoOnly: true });
});

// Local-only token helper. Never enable in production; replace with a verified OTP provider.
app.post("/dev/token", (req, res) => {
  if (process.env.ALLOW_DEV_AUTH !== "true") return res.status(404).end();
  const schema = z.object({ userId: z.string().min(1) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid userId" });
  return res.json({ token: jwt.sign({ sub: parsed.data.userId }, jwtSecret!, { expiresIn: "30m" }) });
});

app.get("/me", auth, async (req: AuthedRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.auth!.sub }, select: { id: true, displayName: true, createdAt: true } });
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json(user);
});

// Phone number is returned only to the other participant of an ACCEPTED 1:1 chat.
app.get("/conversations/:id/contact", auth, async (req: AuthedRequest, res) => {
  const conversation = await prisma.conversation.findUnique({ where: { id: req.params.id } });
  if (!isParticipant(conversation, req.auth!.sub) || conversation!.status !== ConversationStatus.ACCEPTED) {
    return res.status(404).json({ error: "Contact unavailable" });
  }
  const targetId = otherParticipant(conversation, req.auth!.sub);
  const target = await prisma.user.findUnique({ where: { id: targetId } });
  if (!target) return res.status(404).json({ error: "Contact unavailable" });
  const phone = decrypt(target.phoneCiphertext, target.phoneIv, target.phoneAuthTag);
  res.json({ displayName: target.displayName, phone });
});

app.post("/conversations/:id/messages", auth, async (req: AuthedRequest, res) => {
  const parsed = z.object({ body: z.string().trim().min(1).max(5000) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Message must be 1–5000 characters" });
  const conversation = await prisma.conversation.findUnique({ where: { id: req.params.id } });
  if (!isParticipant(conversation, req.auth!.sub) || conversation!.status !== ConversationStatus.ACCEPTED) {
    return res.status(403).json({ error: "An accepted conversation is required" });
  }
  const encrypted = encrypt(parsed.data.body);
  const message = await prisma.message.create({ data: {
    conversationId: conversation!.id, senderId: req.auth!.sub,
    bodyCiphertext: encrypted.ciphertext, bodyIv: encrypted.iv, bodyAuthTag: encrypted.tag
  }, select: { id: true, senderId: true, createdAt: true } });
  res.status(201).json(message);
});

// A user may report a specific message. The review endpoint decrypts only that reported message.
app.post("/conversations/:id/reports", auth, async (req: AuthedRequest, res) => {
  const parsed = z.object({
    messageId: z.string().optional(),
    reason: z.enum(["HARASSMENT", "THREATS", "SCAM", "NON_CONSENSUAL_CONTENT", "OTHER"]),
    details: z.string().max(1000).optional()
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid report" });
  const conversation = await prisma.conversation.findUnique({ where: { id: req.params.id } });
  if (!isParticipant(conversation, req.auth!.sub)) return res.status(404).json({ error: "Conversation not found" });
  if (parsed.data.messageId) {
    const message = await prisma.message.findUnique({ where: { id: parsed.data.messageId } });
    if (!message || message.conversationId !== conversation!.id) return res.status(400).json({ error: "Message is not in this conversation" });
  }
  const report = await prisma.report.create({ data: {
    reporterId: req.auth!.sub, conversationId: conversation!.id,
    messageId: parsed.data.messageId, reason: parsed.data.reason, details: parsed.data.details
  }, select: { id: true, status: true, createdAt: true } });
  res.status(201).json(report);
});

// Moderator review is scoped to an existing report and always creates an audit event.
app.get("/moderation/reports/:id", moderatorAuth, async (req: AuthedRequest, res) => {
  const moderator = (req as any).moderator;
  const report = await prisma.report.findUnique({
    where: { id: req.params.id },
    include: { message: true, reporter: { select: { id: true, displayName: true } }, conversation: { select: { id: true } } }
  });
  if (!report) return res.status(404).json({ error: "Report not found" });
  await prisma.auditLog.create({ data: {
    moderatorId: moderator.id, reportId: report.id,
    action: AuditAction.REPORT_VIEWED, reason: `Reviewing report ${report.id}`
  }});
  let reportedMessage: string | null = null;
  if (report.message) {
    reportedMessage = decrypt(report.message.bodyCiphertext, report.message.bodyIv, report.message.bodyAuthTag);
  }
  res.json({
    id: report.id, reason: report.reason, details: report.details, status: report.status,
    createdAt: report.createdAt, reporter: report.reporter, reportedMessage
  });
});

app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  console.error("Unhandled API error", err);
  res.status(500).json({ error: "Internal server error" });
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`AfterHours API listening on ${port}`));
